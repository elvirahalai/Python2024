import csv
from openpyxl import Workbook
from datetime import datetime

def calculate_age(birth_date):
    today = datetime.today()
    return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

try:
    workbook = Workbook()
    sheets = {
        "allall": workbook.active,
        "younger_18": workbook.create_sheet(title="younger_18"),
        "18_45": workbook.create_sheet(title="18_45"),
        "45_70": workbook.create_sheet(title="45_70"),
        "older_70": workbook.create_sheet(title="older_70")
    }
    sheets["allall"].title = "allall"

    with open('employees.csv', mode='r', encoding='utf-8') as file:
        reader = csv.reader(file)
        header = next(reader)

        for sheet in sheets.values():
            sheet.append(header + ["Вік"])

        for row in reader:
            birth_date = datetime.strptime(row[4], "%Y-%m-%d")
            age = calculate_age(birth_date)
            row_with_age = row + [age]

            sheets["allall"].append(row_with_age)

            if age < 18:
                sheets["younger_18"].append(row_with_age)
            elif 18 <= age <= 45:
                sheets["18_45"].append(row_with_age)
            elif 45 <= age <= 70:
                sheets["45_70"].append(row_with_age)
            else:
                sheets["older_70"].append(row_with_age)

    workbook.save('employees.xlsx')
    print("OkOk")
except FileNotFoundError:
    print("Повідомлення про відсутність, або проблеми при відкритті файлу CSV.")
except Exception as e:
    print("Повідомлення про неможливість створення XLSX файлу:", e)
