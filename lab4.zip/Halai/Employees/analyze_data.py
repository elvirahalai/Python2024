import csv
import matplotlib.pyplot as plt
from collections import Counter
from datetime import datetime

def calculate_age(birth_date):
    today = datetime.today()
    return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

try:
    with open('employees.csv', mode='r', encoding='utf-8') as file:
        reader = csv.reader(file)
        header = next(reader)

        gender_counter = Counter()
        age_groups_counter = Counter()
        gender_age_groups_counter = {
            "male": Counter(),
            "female": Counter()
        }

        for row in reader:
            gender = 'male' if row[3] == 'Чоловіча' else 'female'
            birth_date = datetime.strptime(row[4], "%Y-%m-%d")
            age = calculate_age(birth_date)

            gender_counter[gender] += 1

            if age < 18:
                age_group = "younger_18"
            elif 18 <= age <= 45:
                age_group = "18_45"
            elif 45 <= age <= 70:
                age_group = "45_70"
            else:
                age_group = "older_70"

            age_groups_counter[age_group] += 1
            gender_age_groups_counter[gender][age_group] += 1

    # Вивід результатів у консоль
    print("Кількість співробітників за статтю:", gender_counter)
    print("Кількість співробітників за віковими категоріями:", age_groups_counter)
    print("Кількість співробітників за статтю та віковими категоріями:", gender_age_groups_counter)

    # Побудова діаграм
    def plot_counter(counter, title):
        plt.figure(figsize=(10, 5))
        plt.bar(counter.keys(), counter.values())
        plt.title(title)
        plt.show()

    plot_counter(gender_counter, "Кількість співробітників за статтю")
    plot_counter(age_groups_counter, "Кількість співробітників за віковими категоріями")

    for gender, counter in gender_age_groups_counter.items():
        plot_counter(counter, f"Кількість співробітників ({gender}) за віковими категоріями")

except FileNotFoundError:
    print("Повідомлення про відсутність, або проблеми при відкритті файлу CSV.")
except Exception as e:
    print("Помилка:", e)
else:
    print("OkOk")
