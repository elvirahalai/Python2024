import csv
import random
from faker import Faker

# Ініціалізація Faker з українською локалізацією
fake = Faker('uk_UA')

# Словники для "по батькові"
male_patronymics = [
    "Андрійович", "Борисович", "Васильович", "Григорович", "Дмитрович",
    "Євгенович", "Іванович", "Кирилович", "Леонідович", "Миколайович",
    "Олександрович", "Петрович", "Романович", "Сергійович", "Тарасович",
    "Федорович", "Юрійович", "Ярославович", "Макарович", "Олексійович"
]

female_patronymics = [
    "Андріївна", "Борисівна", "Василівна", "Григорівна", "Дмитрівна",
    "Євгенівна", "Іванівна", "Кирилівна", "Леонідівна", "Миколаївна",
    "Олександрівна", "Петрівна", "Романівна", "Сергіївна", "Тарасівна",
    "Федорівна", "Юріївна", "Ярославівна", "Макарівна", "Олексіївна"
]

# Генерування даних та запис у CSV файл
with open('employees.csv', mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Прізвище', 'Ім’я', 'По батькові', 'Стать', 'Дата народження', 'Посада', 'Місто проживання', 'Адреса проживання', 'Телефон', 'Email'])

    for _ in range(2000):
        gender = random.choice(['male', 'female'])
        if gender == 'male':
            first_name = fake.first_name_male()
            patronymic = random.choice(male_patronymics)
        else:
            first_name = fake.first_name_female()
            patronymic = random.choice(female_patronymics)

        last_name = fake.last_name()
        birth_date = fake.date_of_birth(minimum_age=16, maximum_age=85)
        position = fake.job()
        city = fake.city()
        address = fake.address()
        phone = fake.phone_number()
        email = fake.email()

        writer.writerow([last_name, first_name, patronymic, 'Чоловіча' if gender == 'male' else 'Жіноча', birth_date, position, city, address, phone, email])
