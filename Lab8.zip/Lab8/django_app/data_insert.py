import os
import django

# Ініціалізація Django оточення
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'django_app.settings')
django.setup()

from hr.models import Department, Position, Employee, Project, ProjectExecution

def insert_data():
    # Заповнення таблиці Departments
    departments = [
        {'name': 'Програмування', 'phone': '+380123456789', 'room_number': 701},
        {'name': 'Дизайн', 'phone': '+380987654321', 'room_number': 702},
        {'name': 'ІТ', 'phone': '+380123987654', 'room_number': 703},
    ]
    for dep in departments:
        Department.objects.get_or_create(**dep)

    # Заповнення таблиці Positions
    positions = [
        {'title': 'Програміст', 'salary': 3000, 'bonus_percent': 10},
        {'title': 'Інженер', 'salary': 2500, 'bonus_percent': 5},
        {'title': 'Редактор', 'salary': 1900, 'bonus_percent': 7},
    ]
    for pos in positions:
        Position.objects.get_or_create(**pos)

    employees = [
        {'last_name': 'Іваненко', 'first_name': 'Іван', 'middle_name': 'Іванович', 'address': 'вул. Шевченка, 10',
         'phone': '+380671234567', 'education': 'вища', 'department_id': 1, 'position_id': 1},
        {'last_name': 'Петренко', 'first_name': 'Петро', 'middle_name': 'Петрович', 'address': 'вул. Грушевського, 5',
         'phone': '+380661234567', 'education': 'середня', 'department_id': 1, 'position_id': 2},
        {'last_name': 'Сидоренко', 'first_name': 'Ольга', 'middle_name': 'Олексіївна', 'address': 'вул. Франка, 3',
         'phone': '+380931234567', 'education': 'спеціальна', 'department_id': 2, 'position_id': 3},
        {'last_name': 'Коваль', 'first_name': 'Андрій', 'middle_name': 'Сергійович',
         'address': 'вул. Лесі Українки, 12', 'phone': '+380501234567', 'education': 'вища', 'department_id': 3,
         'position_id': 1},
        {'last_name': 'Мельник', 'first_name': 'Олександр', 'middle_name': 'Олегович', 'address': 'вул. Довженка, 7',
         'phone': '+380501234568', 'education': 'спеціальна', 'department_id': 1, 'position_id': 2},
        {'last_name': 'Тарасенко', 'first_name': 'Марина', 'middle_name': 'Володимирівна',
         'address': 'вул. Сагайдачного, 6', 'phone': '+380951234569', 'education': 'вища', 'department_id': 2,
         'position_id': 3},
        {'last_name': 'Гнатенко', 'first_name': 'Оксана', 'middle_name': 'Іванівна', 'address': 'вул. Лермонтова, 9',
         'phone': '+380731234570', 'education': 'середня', 'department_id': 2, 'position_id': 1},
        {'last_name': 'Литвиненко', 'first_name': 'Юрій', 'middle_name': 'Васильович', 'address': 'вул. Бандери, 15',
         'phone': '+380671234571', 'education': 'вища', 'department_id': 1, 'position_id': 2},
        {'last_name': 'Кузьменко', 'first_name': 'Катерина', 'middle_name': 'Михайлівна',
         'address': 'вул. Дорошенка, 18', 'phone': '+380991234572', 'education': 'середня', 'department_id': 3,
         'position_id': 1},
        {'last_name': 'Шевчук', 'first_name': 'Сергій', 'middle_name': 'Миколайович', 'address': 'вул. Федорова, 20',
         'phone': '+380661234573', 'education': 'спеціальна', 'department_id': 1, 'position_id': 3},
        {'last_name': 'Романенко', 'first_name': 'Анастасія', 'middle_name': 'Петрівна', 'address': 'вул. Зелена, 5',
         'phone': '+380551234574', 'education': 'вища', 'department_id': 2, 'position_id': 2},
        {'last_name': 'Павленко', 'first_name': 'Галина', 'middle_name': 'Федорівна', 'address': 'вул. Вишнева, 8',
         'phone': '+380441234575', 'education': 'середня', 'department_id': 1, 'position_id': 1},
        {'last_name': 'Захарченко', 'first_name': 'Віктор', 'middle_name': 'Андрійович',
         'address': 'вул. Січових Стрільців, 2', 'phone': '+380551234576', 'education': 'вища', 'department_id': 3,
         'position_id': 2},
    ]
    for emp in employees:
        Employee.objects.get_or_create(**emp)

    # Заповнення таблиці Projects
    projects = [
        {'name': 'Розробка CRM', 'deadline': '2024-12-31', 'budget': 50000},
        {'name': 'Редизайн сайту', 'deadline': '2024-11-30', 'budget': 15000},
        {'name': 'Впровадження ERP', 'deadline': '2025-03-15', 'budget': 80000},
    ]
    for proj in projects:
        Project.objects.get_or_create(**proj)

    # Заповнення таблиці ProjectExecution
    executions = [
        {'project_number_id': 1, 'department_id': 1, 'start_date': '2024-01-01'},
        {'project_number_id': 2, 'department_id': 2, 'start_date': '2024-02-15'},
        {'project_number_id': 3, 'department_id': 3, 'start_date': '2024-03-10'},
    ]
    for exec in executions:
        ProjectExecution.objects.get_or_create(**exec)

    print("Усі дані успішно додані!")

if __name__ == '__main__':
    insert_data()
