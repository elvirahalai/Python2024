from django.shortcuts import render
from .models import Employee, Department, Position, Project, ProjectExecution

def index(request):
    # Отримати дані з усіх таблиць
    employees = Employee.objects.select_related('department', 'position').all()
    departments = Department.objects.all()
    positions = Position.objects.all()
    projects = Project.objects.all()
    project_executions = ProjectExecution.objects.select_related('project_number', 'department').all()

    # Передати дані в шаблон
    context = {
        'project_title': 'Проєкт: Відділ кадрів',
        'student_info': 'Галай Ельвіра Андріївна, Група КІБ-21015Б',
        'employees': employees,
        'departments': departments,
        'positions': positions,
        'projects': projects,
        'project_executions': project_executions
    }
    return render(request, 'hr/index.html', context)
