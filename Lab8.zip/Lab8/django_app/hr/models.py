from django.db import models
from django.core.exceptions import ValidationError
import re


class Department(models.Model):
    department_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50, verbose_name="Назва відділу")
    phone = models.CharField(
        max_length=13,
        verbose_name="Телефон",
        help_text="Формат: +380XXXXXXXXX"
    )
    room_number = models.IntegerField(
        verbose_name="Номер кімнати",
        help_text="Повинен бути між 701 та 710"
    )

    def clean(self):
        # Перевірка маски для телефону
        if not re.match(r'^\+380\d{9}$', self.phone):
            raise ValidationError("Номер телефону повинен бути у форматі +380XXXXXXXXX")

        # Перевірка обмеження на номер кімнати
        if not (701 <= self.room_number <= 710):
            raise ValidationError("Номер кімнати повинен бути між 701 і 710")

    def __str__(self):
        return self.name


class Position(models.Model):
    title = models.CharField(max_length=50)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    bonus_percent = models.IntegerField()

    def __str__(self):
        return self.title

class Employee(models.Model):
    employee_id = models.AutoField(primary_key=True)
    last_name = models.CharField(max_length=50, verbose_name="Прізвище")
    first_name = models.CharField(max_length=50, verbose_name="Ім'я")
    middle_name = models.CharField(max_length=50, verbose_name="По батькові", null=True, blank=True)
    address = models.CharField(max_length=100, verbose_name="Адреса")
    phone = models.CharField(
        max_length=13,
        verbose_name="Телефон",
        help_text="Формат: +380XXXXXXXXX"
    )
    education = models.CharField(
        max_length=20,
        choices=[('спеціальна', 'Спеціальна'), ('середня', 'Середня'), ('вища', 'Вища')],
        verbose_name="Освіта"
    )
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    position = models.ForeignKey(Position, on_delete=models.CASCADE)

    def clean(self):
        # Перевірка маски для телефону співробітника
        if not re.match(r'^\+380\d{9}$', self.phone):
            raise ValidationError("Номер телефону повинен бути у форматі +380XXXXXXXXX")

    def __str__(self):
        return f"{self.last_name} {self.first_name}"

class Project(models.Model):
    name = models.CharField(max_length=100)
    deadline = models.DateField()
    budget = models.DecimalField(max_digits=15, decimal_places=2)

    def __str__(self):
        return self.name

class ProjectExecution(models.Model):
    project_number = models.ForeignKey(Project, on_delete=models.CASCADE)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    start_date = models.DateField()

    def __str__(self):
        return f"{self.project_number} - {self.department}"
