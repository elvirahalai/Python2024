from django.contrib import admin
from .models import Department, Position, Employee, Project, ProjectExecution

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ['name', 'phone', 'room_number']
    search_fields = ['name']
    list_filter = ['room_number']
    ordering = ['name']

@admin.register(Position)
class PositionAdmin(admin.ModelAdmin):
    list_display = ['title', 'salary', 'bonus_percent']
    search_fields = ['title']
    list_filter = ['bonus_percent']
    ordering = ['title']

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['last_name', 'first_name', 'middle_name', 'department', 'position', 'education', 'phone']
    search_fields = ['last_name', 'first_name', 'phone']
    list_filter = ['department', 'position', 'education']
    ordering = ['last_name']
    autocomplete_fields = ['department', 'position']  # Дозволяє швидкий пошук по зовнішніх ключах

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['name', 'deadline', 'budget']
    search_fields = ['name']
    list_filter = ['deadline']
    ordering = ['deadline']

@admin.register(ProjectExecution)
class ProjectExecutionAdmin(admin.ModelAdmin):
    list_display = ['project_number', 'department', 'start_date']
    search_fields = ['project_number__name', 'department__name']
    list_filter = ['start_date']
    ordering = ['start_date']
    autocomplete_fields = ['project_number', 'department']  # Дозволяє швидкий пошук по зовнішніх ключах
