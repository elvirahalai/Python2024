from translator_package.deep_translate_module import translate
from deep_translator import GoogleTranslator

translator = GoogleTranslator()

translated_text = translate("Hello That's good", "en", "uk")
print(f"Переклад фрази 'Hello That's good' з англійської: {translated_text}")

languages = translator.get_supported_languages(as_dict=True)

print(f"\n{'N':<3} {'ISO-639 code':<20} {'Language':<10}")
print('-' * 35)
for index, (code, name) in enumerate(languages.items(), start=1):
    print(f"{index:<3} {name:<20} {code:<10}")
