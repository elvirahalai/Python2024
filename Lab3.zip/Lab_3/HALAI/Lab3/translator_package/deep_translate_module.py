from langdetect import detect, detect_langs
from deep_translator import GoogleTranslator

from deep_translator import GoogleTranslator

translator = GoogleTranslator()  # Створюємо екземпляр класу


def translate(text: str, src: str, dest: str) -> str:
    """Функція повертає текст перекладений на задану мову, або повідомлення про помилку."""
    try:
        translated = GoogleTranslator(source=src, target=dest).translate(text)
        return translated
    except Exception as e:
        return f"Помилка: {e}"


def get_supported_languages() -> list:
    """Функція повертає список підтримуваних мов."""
    try:
        return translator.get_supported_languages()  # Використовуємо екземпляр класу для виклику методу
    except Exception as e:
        return f"Помилка: {e}"


def lang_detect(text: str, set: str = "all") -> str:
    """Функція визначає мову та коефіцієнт довіри для заданого тексту."""
    try:
        if set == "lang":
            return detect(text)
        elif set == "confidence":
            detections = detect_langs(text)
            return str(detections[0].prob) if detections else "Не вдалося визначити"
        elif set == "all":
            detections = detect_langs(text)
            if detections:
                return f"{detections[0].lang}, {detections[0].prob}"
            else:
                return "Не вдалося визначити"
        else:
            return "Невірний параметр set"
    except Exception as e:
        return f"Помилка: {e}"


def code_lang(lang: str) -> str:
    """Функція повертає код мови або назву мови."""
    try:
        languages = GoogleTranslator.get_supported_languages(as_dict=True)
        if lang in languages:
            return languages[lang]
        else:
            for code, name in languages.items():
                if name == lang:
                    return code
        return "Помилка: Невірна мова або код"
    except Exception as e:
        return f"Помилка: {e}"


def language_list(out: str = "screen", text: str = None) -> str:
    """Виводить таблицю мов та їх кодів, а також текст перекладений на цю мову."""
    try:
        languages = GoogleTranslator.get_supported_languages(as_dict=True)
        result = []

        for index, (code, name) in enumerate(languages.items(), 1):
            if text:
                translated_text = translate(text, 'auto', code)
                result.append(f"{index:<3} {name:<20} {code:<10} {translated_text}")
            else:
                result.append(f"{index:<3} {name:<20} {code:<10}")

        header = f"{'N':<3} {'Language':<20} {'ISO-639 code':<10} {'Text' if text else ''}"
        output = header + '\n' + '-' * len(header) + '\n' + '\n'.join(result)

        if out == "screen":
            print(output)
        elif out == "file":
            with open("languages_list_deep.txt", "w", encoding="utf-8") as f:
                f.write(output)
        else:
            return "Помилка: невірний параметр out"

        return "Ok"
    except Exception as e:
        return f"Помилка: {e}"
