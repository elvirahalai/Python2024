from googletrans import Translator
from googletrans.constants import LANGUAGES

translator = Translator()

def translate(text: str, src: str, dest: str) -> str:
    try:
        translated = translator.translate(text, src=src, dest=dest)
        return translated.text
    except Exception as e:
        return f"Помилка: {e}"

def lang_detect(text: str, set: str = "all") -> str:
    try:
        detection = translator.detect(text)
        if set == "lang":
            return detection.lang
        elif set == "confidence":
            return str(detection.confidence)
        elif set == "all":
            return f"{detection.lang}, {detection.confidence}"
        else:
            return "Помилка: Невірний параметр set"
    except Exception as e:
        return f"Помилка: {e}"

def code_lang(lang: str) -> str:
    try:
        if lang in LANGUAGES:
            return LANGUAGES[lang]
        else:
            for code, name in LANGUAGES.items():
                if name.lower() == lang.lower():
                    return code
        return "Помилка: Невірна мова або код"
    except Exception as e:
        return f"Помилка: {e}"

def language_list(out: str = "screen", text: str = None) -> str:
    try:
        result = []

        for index, (code, name) in enumerate(LANGUAGES.items(), 1):
            if text:
                translated_text = translate(text, 'auto', code)
                result.append(f"{index:<3} {code:<10} {name:<20} {translated_text}")
            else:
                result.append(f"{index:<3} {code:<10} {name:<20}")

        header = f"{'N':<3} {'Code':<10} {'Language':<20} {'Text' if text else ''}"
        output = header + '\n' + '-' * len(header) + '\n' + '\n'.join(result)

        if out == "screen":
            print(output)
        elif out == "file":
            with open("languages_list.txt", "w", encoding="utf-8") as f:
                f.write(output)
        else:
            return "Помилка: невірний параметр out"

        return "Ok"
    except Exception as e:
        return f"Помилка: {e}"
