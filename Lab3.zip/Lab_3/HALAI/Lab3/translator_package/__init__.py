NAME = "Text translation"
AUTHOR = "Галай Ельвіра, КІБ-21015Б"
