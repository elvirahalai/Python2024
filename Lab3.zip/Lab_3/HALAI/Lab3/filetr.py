import os
import json
from translator_package.google_translate_module import translate, lang_detect


def read_config(config_path: str) -> dict:
    try:
        with open(config_path, "r", encoding="utf-8") as config_file:
            return json.load(config_file)
    except FileNotFoundError:
        print("Помилка: Конфігураційний файл не знайдено.")
        return None
    except json.JSONDecodeError:
        print("Помилка: Невірний формат конфігураційного файлу.")
        return None


def file_statistics(text: str) -> dict:
    return {
        "characters": len(text),
        "words": len(text.split()),
        "sentences": text.count('.') + text.count('!') + text.count('?')
    }


def main():
    config = read_config("config.txt")
    if not config:
        return

    text_file = config.get("filename")
    target_language = config.get("target_language")
    output = config.get("output")
    max_characters = config.get("max_characters")
    max_words = config.get("max_words")
    max_sentences = config.get("max_sentences")

    if not os.path.exists(text_file):
        print(f"Помилка: Файл '{text_file}' не знайдено.")
        return

    with open(text_file, "r", encoding="utf-8") as file:
        text = file.read()

    stats = file_statistics(text)
    print(f"Назва файлу: {text_file}")
    print(f"Розмір файлу: {os.path.getsize(text_file)} байт")
    print(f"Кількість символів: {stats['characters']}")
    print(f"Кількість слів: {stats['words']}")
    print(f"Кількість речень: {stats['sentences']}")
    print(f"Мова тексту: {lang_detect(text, set='lang')}")

    current_text = ""
    characters_count, words_count, sentences_count = 0, 0, 0

    for line in text.splitlines():
        for word in line.split():
            if characters_count + len(
                    word) > max_characters or words_count >= max_words or sentences_count >= max_sentences:
                break

            current_text += word + " "
            characters_count += len(word) + 1
            words_count += 1
            sentences_count += word.count('.') + word.count('!') + word.count('?')

    translated_text = translate(current_text.strip(), "auto", target_language)

    if output == "screen":
        print(f"\nМова перекладу: {target_language}")
        print(f"Перекладений текст:\n{translated_text}")
    elif output == "file":
        output_filename = f"{os.path.splitext(text_file)[0]}_{target_language}.txt"
        try:
            with open(output_filename, "w", encoding="utf-8") as output_file:
                output_file.write(translated_text)
            print(f"Ok: Результат збережено у файл '{output_filename}'")
        except Exception as e:
            print(f"Помилка при записі у файл: {e}")
    else:
        print("Помилка: Невірний параметр виводу.")


if __name__ == "__main__":
    main()
