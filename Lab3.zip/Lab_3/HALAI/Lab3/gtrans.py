from translator_package.google_translate_module import translate, lang_detect, code_lang, language_list

result = translate("Hello", "en", "uk")
print(f"Переклад слова 'Hello' з англійської: {result}")

lang_result = lang_detect("Добрий день")
print(f"Визначення мови для тексту 'Добрий день': {lang_result}")

code_result = code_lang("Ukrainian")
print(f"Код мови для 'Ukrainian': {code_result}")

print("Список підтримуваних мов і переклад тексту 'Добрий день':")
language_list_result = language_list("screen", "Добрий день")
print(language_list_result)
