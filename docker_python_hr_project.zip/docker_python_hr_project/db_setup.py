import psycopg2

DB_NAME = "hr_db"
DB_USER = "admin"
DB_PASSWORD = "admin123"
DB_HOST = "localhost"
DB_PORT = "5432"

def create_connection():
    return psycopg2.connect(
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        host=DB_HOST,
        port=DB_PORT
    )

def create_tables():
    conn = create_connection()
    cursor = conn.cursor()

    # Таблиця: Відділи (Departments)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Departments (
            department_id SERIAL PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            phone VARCHAR(20) CHECK (phone ~ '^\+\d{12}$'), -- Маска для телефону
            room_number INT CHECK (room_number BETWEEN 701 AND 710) -- Обмеження на номер кімнати
        );
    ''')

    # Таблиця: Посади (Positions)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Positions (
            position_id SERIAL PRIMARY KEY,
            title VARCHAR(50) NOT NULL,
            salary NUMERIC(10, 2) CHECK (salary > 0), -- Оклад має бути позитивним числом
            bonus_percent INT DEFAULT 0 CHECK (bonus_percent BETWEEN 0 AND 100) -- Премія у відсотках
        );
    ''')

    # Таблиця: Співробітники (Employees)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Employees (
            employee_id SERIAL PRIMARY KEY,
            last_name VARCHAR(50) NOT NULL,
            first_name VARCHAR(50) NOT NULL,
            middle_name VARCHAR(50),
            address VARCHAR(100),
            phone VARCHAR(20) CHECK (phone ~ '^\+\d{12}$'), -- Маска для телефону
            education VARCHAR(20) CHECK (education IN ('спеціальна', 'середня', 'вища')), -- Обмеження на значення
            department_id INT REFERENCES Departments(department_id),
            position_id INT REFERENCES Positions(position_id)
        );
    ''')

    # Таблиця: Проекти (Projects)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Projects (
            project_number SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            deadline DATE,
            budget NUMERIC(15, 2) CHECK (budget > 0) -- Бюджет має бути позитивним
        );
    ''')

    # Таблиця: Виконання проектів (ProjectExecution)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ProjectExecution (
            execution_id SERIAL PRIMARY KEY,
            project_number INT REFERENCES Projects(project_number),
            department_id INT REFERENCES Departments(department_id),
            start_date DATE NOT NULL DEFAULT CURRENT_DATE
        );
    ''')

    conn.commit()
    cursor.close()
    conn.close()
    print("Таблиці створено успішно з урахуванням типів даних та обмежень!")

if __name__ == '__main__':
    create_tables()
