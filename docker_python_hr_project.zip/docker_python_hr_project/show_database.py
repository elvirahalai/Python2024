import psycopg2
from tabulate import tabulate

DB_NAME = "hr_db"
DB_USER = "admin"
DB_PASSWORD = "admin123"
DB_HOST = "localhost"
DB_PORT = "5432"

def create_connection():
    """Створення підключення до бази даних"""
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT
        )
        return conn
    except Exception as e:
        print(f"Помилка підключення до бази даних: {e}")
        return None

def show_tables(conn):
    """Отримання списку таблиць у базі даних"""
    cursor = conn.cursor()
    cursor.execute("""
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public'
    """)
    tables = cursor.fetchall()
    print("\nТаблиці у базі даних:")
    for table in tables:
        print(f"- {table[0]}")
    return [table[0] for table in tables]

def show_table_structure(conn, table):
    """Виведення структури таблиці"""
    cursor = conn.cursor()
    cursor.execute(f"SELECT column_name, data_type FROM information_schema.columns WHERE table_name = '{table}'")
    columns = cursor.fetchall()
    print(f"\nСтруктура таблиці '{table}':")
    print(tabulate(columns, headers=["Стовпець", "Тип даних"], tablefmt="psql"))

def show_table_data(conn, table):
    """Виведення даних з таблиці"""
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM {table}")
    rows = cursor.fetchall()
    if rows:
        print(f"\nДані з таблиці '{table}':")
        column_names = [desc[0] for desc in cursor.description]
        print(tabulate(rows, headers=column_names, tablefmt="psql"))
    else:
        print(f"\nТаблиця '{table}' порожня")

def execute_queries(conn):
    """Виконання запитів та виведення результатів"""
    cursor = conn.cursor()

    # Запит 1: Вивести працівників з окладом більше 2000 грн
    cursor.execute('''
        SELECT e.last_name, e.first_name, p.salary
        FROM Employees e
        JOIN Positions p ON e.position_id = p.position_id
        WHERE p.salary > 2000
        ORDER BY e.last_name;
    ''')
    rows = cursor.fetchall()
    print("\nПрацівники з окладом більше 2000 грн:")
    print(tabulate(rows, headers=["Прізвище", "Ім'я", "Оклад"], tablefmt="psql"))

    # Запит 2: Середня зарплата у кожному відділі
    cursor.execute('''
        SELECT d.name, ROUND(AVG(p.salary), 2) AS average_salary
        FROM Employees e
        JOIN Positions p ON e.position_id = p.position_id
        JOIN Departments d ON e.department_id = d.department_id
        GROUP BY d.name;
    ''')
    rows = cursor.fetchall()
    print("\nСередня зарплата по відділах:")
    print(tabulate(rows, headers=["Відділ", "Середня зарплата"], tablefmt="psql"))

    # Запит 3: Відобразити всі проекти у відділі
    department_id = 1
    cursor.execute('''
        SELECT p.name, pe.start_date
        FROM Projects p
        JOIN ProjectExecution pe ON p.project_number = pe.project_number
        WHERE pe.department_id = %s;
    ''', (department_id,))
    rows = cursor.fetchall()
    print(f"\nПроекти у відділі {department_id}:")
    print(tabulate(rows, headers=["Проект", "Дата початку"], tablefmt="psql"))

    # Запит 4: Кількість працівників у кожному відділі
    cursor.execute('''
        SELECT d.name, COUNT(e.employee_id) AS employee_count
        FROM Employees e
        JOIN Departments d ON e.department_id = d.department_id
        GROUP BY d.name;
    ''')
    rows = cursor.fetchall()
    print("\nКількість працівників по відділах:")
    print(tabulate(rows, headers=["Відділ", "Кількість працівників"], tablefmt="psql"))

    # Запит 5: Порахувати розмір премії для кожного співробітника
    cursor.execute('''
        SELECT e.last_name, e.first_name, p.salary, p.bonus_percent,
               ROUND((p.salary * p.bonus_percent / 100), 2) AS bonus_amount
        FROM Employees e
        JOIN Positions p ON e.position_id = p.position_id;
    ''')
    rows = cursor.fetchall()
    print("\nПремії для кожного співробітника:")
    print(tabulate(rows, headers=["Прізвище", "Ім'я", "Оклад", "Премія %", "Сума премії"], tablefmt="psql"))

    # Запит 6: Порахувати кількість робітників за рівнем освіти у кожному відділі
    cursor.execute('''
        SELECT d.name,
               SUM(CASE WHEN e.education = 'спеціальна' THEN 1 ELSE 0 END) AS special_education,
               SUM(CASE WHEN e.education = 'середня' THEN 1 ELSE 0 END) AS secondary_education,
               SUM(CASE WHEN e.education = 'вища' THEN 1 ELSE 0 END) AS higher_education
        FROM Employees e
        JOIN Departments d ON e.department_id = d.department_id
        GROUP BY d.name;
    ''')
    rows = cursor.fetchall()
    print("\nКількість працівників за рівнем освіти у кожному відділі:")
    print(tabulate(rows, headers=["Відділ", "Спеціальна", "Середня", "Вища"], tablefmt="psql"))

    cursor.close()

def main():
    conn = create_connection()
    if conn:
        tables = show_tables(conn)
        for table in tables:
            show_table_structure(conn, table)
            show_table_data(conn, table)
        execute_queries(conn)
        conn.close()
    else:
        print("Неможливо підключитися до бази даних")

if __name__ == '__main__':
    main()
